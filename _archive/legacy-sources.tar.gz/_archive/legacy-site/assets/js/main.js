document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const textInput = document.getElementById('text-input');
    const translateBtn = document.getElementById('translate-btn');
    const showAlphabetBtn = document.getElementById('show-alphabet-btn');
    const resultContent = document.getElementById('result-content');
    const viewButtons = document.querySelectorAll('.view-btn');
    const fixedWidth = document.getElementById('fixed-width');
    const highlightCapitals = document.getElementById('highlight-capitals');
    const sizeSelect = document.getElementById('size');
    const languageSelector = document.getElementById('language-selector');
    const mobileToggle = document.getElementById('mobileToggle');
    const navList = document.getElementById('navList');
    
    // Mobile menu toggle
    if (mobileToggle) {
        mobileToggle.addEventListener('click', function() {
            navList.classList.toggle('active');
            const icon = mobileToggle.querySelector('i');
            if (navList.classList.contains('active')) {
                icon.classList.remove('fa-bars');
                icon.classList.add('fa-times');
            } else {
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
            }
        });
    }
    
    // Close mobile menu when clicking on a link
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function() {
            if (navList) {
                navList.classList.remove('active');
                if (mobileToggle) {
                    const icon = mobileToggle.querySelector('i');
                    icon.classList.remove('fa-times');
                    icon.classList.add('fa-bars');
                }
            }
        });
    });
    
    // Current view mode
    let currentView = 'words';
    
    // ASL Sign Language images mapping
    const aslSigns = {
       'a': 'assets/images/a.webp', 'b': 'assets/images/b.webp', 'c': 'assets/images/c.webp', 'd': 'assets/images/d.webp', 'e': 'assets/images/e.webp', 'f': 'assets/images/f.webp', 'g': 'assets/images/g.webp', 'h': 'assets/images/h.webp', 'i': 'assets/images/i.webp', 'j': 'assets/images/j.webp', 'k': 'assets/images/k.webp', 'l': 'assets/images/l.webp', 'm': 'assets/images/m.webp', 'n': 'assets/images/n.webp', 'o': 'assets/images/o.webp', 'p': 'assets/images/p.webp', 'q': 'assets/images/q.webp', 'r': 'assets/images/r.webp', 's': 'assets/images/s.webp', 't': 'assets/images/t.webp', 'u': 'assets/images/u.webp', 'v': 'assets/images/v.webp', 'w': 'assets/images/w.webp', 'x': 'assets/images/x.webp', 'y': 'assets/images/y.webp', 'z': 'assets/images/z.webp', '0': 'assets/images/0.webp', '1': 'assets/images/1.webp', '2': 'assets/images/2.webp', '3': 'assets/images/3.webp', '4': 'assets/images/4.webp', '5': 'assets/images/5.webp', '6': 'assets/images/6.webp', '7': 'assets/images/7.webp', '8': 'assets/images/8.webp', '9': 'assets/images/9.webp'
    };
    
    // Add change event to language selector if it exists
    if (languageSelector) {
        languageSelector.addEventListener('change', function() {
            openLink(this);
        });
    }
    
    // Also add event listeners to any other language selection dropdowns
    // This ensures all dropdowns with the class 'language-dropdown' will trigger navigation
    const allLanguageDropdowns = document.querySelectorAll('.language-dropdown, [id^="link"]');
    allLanguageDropdowns.forEach(dropdown => {
        dropdown.addEventListener('change', function() {
            openLink(this);
        });
    });
    
    // Function to open the selected language link
    function openLink(selectElement) {
        const selectedValue = selectElement.value;
        if (selectedValue) {
            window.location.href = selectedValue;
            // Reset the dropdown to the default option after opening the link
            selectElement.selectedIndex = 0;
        }
    }
    
    // View toggle
    viewButtons.forEach(button => {
        button.addEventListener('click', () => {
            viewButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            currentView = button.getAttribute('data-view');
            renderTranslation();
        });
    });
    
    // Make options work in real-time
    fixedWidth.addEventListener('change', renderTranslation);
    highlightCapitals.addEventListener('change', renderTranslation);
    sizeSelect.addEventListener('change', renderTranslation);
    
    // Translate button click
    translateBtn.addEventListener('click', () => {
        renderTranslation();
    });
    
    // Show alphabet button click
    showAlphabetBtn.addEventListener('click', () => {
        showAlphabet();
    });
    
    // Main render function
    function renderTranslation() {
        const text = textInput.value.trim();
        if (!text) {
            resultContent.innerHTML = '<div class="empty-result"><i class="fas fa-sign-language"></i><p>Enter text to see translation</p></div>';
            return;
        }
        
        resultContent.innerHTML = '';
        
        if (currentView === 'words') {
            renderWordsView(text);
        } else {
            renderLettersView(text);
        }
    }
    
    // Render words view
    function renderWordsView(text) {
        const words = text.split(/\s+/);
        
        words.forEach(word => {
            const signItem = document.createElement('div');
            signItem.className = 'sign-item';
            
            if (fixedWidth.checked) {
                // When fixed width is checked, each card should have consistent width
                signItem.style.width = sizeSelect.value + 'px';
            } else {
                // When fixed width is unchecked, width should auto-adjust to content
                signItem.style.width = 'auto';
            }
            
            const signHeader = document.createElement('div');
            signHeader.className = 'sign-header';
            signHeader.textContent = word;
            
            const signContent = document.createElement('div');
            signContent.className = 'sign-content';
            
            // Add each letter in the word
            word.split('').forEach(letter => {
                const letterLower = letter.toLowerCase();
                
                if (aslSigns[letterLower]) {
                    const signLetter = createSignLetter(letter, letterLower);
                    signContent.appendChild(signLetter);
                }
            });
            
            signItem.appendChild(signHeader);
            signItem.appendChild(signContent);
            resultContent.appendChild(signItem);
        });
    }
    
    // Render letters view
    function renderLettersView(text) {
        const letters = text.split('');
        
        letters.forEach(letter => {
            if (letter === ' ') return; // Skip spaces in letter view
            
            const letterLower = letter.toLowerCase();
            
            if (aslSigns[letterLower]) {
                const signItem = document.createElement('div');
                signItem.className = 'sign-item single-letter';
                
                if (fixedWidth.checked) {
                    // When fixed width is checked, each card should have consistent width
                    signItem.style.width = sizeSelect.value + 'px';
                } else {
                    // When fixed width is unchecked, width should auto-adjust to content
                    signItem.style.width = 'auto';
                }
                
                const signHeader = document.createElement('div');
                signHeader.className = 'sign-header';
                signHeader.textContent = letter;
                
                // Highlight capitals if option is checked
                if (highlightCapitals.checked && letter !== letterLower) {
                    signHeader.style.backgroundColor = '#006064';
                }
                
                const signContent = document.createElement('div');
                signContent.className = 'sign-content';
                
                const signLetter = createSignLetter(letter, letterLower);
                signContent.appendChild(signLetter);
                
                signItem.appendChild(signHeader);
                signItem.appendChild(signContent);
                resultContent.appendChild(signItem);
            }
        });
    }
    
    // Create a single sign letter element
    function createSignLetter(letter, letterLower) {
        const signLetter = document.createElement('div');
        signLetter.className = 'sign-letter';
        
        const signImage = document.createElement('div');
        signImage.className = 'sign-image';
        
        // Apply size based on selection
        const size = parseInt(sizeSelect.value);
        signImage.style.width = `${size - 40}px`;
        signImage.style.height = `${size - 20}px`;
        
        const img = document.createElement('img');
        img.src = aslSigns[letterLower];
        img.alt = `Sign for ${letter}`;
        
        signImage.appendChild(img);
        signLetter.appendChild(signImage);
        
        return signLetter;
    }
    
    // Show full alphabet
    function showAlphabet() {
        resultContent.innerHTML = '';
        
        Object.keys(aslSigns).forEach(letter => {
            if (letter.match(/[a-z0-9]/i)) { // Only show letters, not numbers
                const signItem = document.createElement('div');
                signItem.className = 'sign-item single-letter';
                
                if (fixedWidth.checked) {
                    signItem.style.width = sizeSelect.value + 'px';
                }
                
                const signHeader = document.createElement('div');
                signHeader.className = 'sign-header';
                signHeader.textContent = letter.toUpperCase();
                
                const signContent = document.createElement('div');
                signContent.className = 'sign-content';
                
                const signLetter = createSignLetter(letter.toUpperCase(), letter);
                signContent.appendChild(signLetter);
                
                signItem.appendChild(signHeader);
                signItem.appendChild(signContent);
                resultContent.appendChild(signItem);
            }
        });
        
        // Switch view to letters
        viewButtons.forEach(btn => {
            btn.classList.remove('active');
            if (btn.getAttribute('data-view') === 'letters') {
                btn.classList.add('active');
            }
        });
        currentView = 'letters';
    }
    
    // Demo - pre-fill with "I Love You"
    textInput.value = "I Love You";
    
    // Ensure Fixed Width is off initially
    fixedWidth.checked = false;
    
    renderTranslation();
    
    // Newsletter subscription functionality
    const newsletterForm = document.getElementById('newsletter-form');
    const newsletterEmail = document.getElementById('newsletter-email');
    const newsletterMessage = document.getElementById('newsletter-message');
    
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = newsletterEmail.value.trim();
            
            // Basic email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                showNewsletterMessage('Please enter a valid email address', 'error');
                return;
            }
            
            // In a real application, you would send this to a server
            // For demonstration, we'll simulate a successful submission
            sendSubscriptionEmail(email);
        });
    }
    
    function sendSubscriptionEmail(email) {
        // Show loading state
        const newsletterBtn = document.getElementById('newsletter-btn');
        if (!newsletterBtn) return;
        
        const originalButtonText = newsletterBtn.textContent;
        newsletterBtn.textContent = 'Sending...';
        newsletterBtn.disabled = true;
        
        // Simulate server request with timeout
        setTimeout(() => {
            // This is where you would normally send an AJAX request to your server
            console.log(`Subscription email: ${email} would be sent to zahidrazzaq279@gmail.com`);
            
            // Reset form and show success message
            newsletterEmail.value = '';
            showNewsletterMessage('Thank you for subscribing!', 'success');
            
            // Change button to "Subscribed" state
            newsletterBtn.textContent = 'Subscribed';
            newsletterBtn.disabled = true;
            newsletterBtn.classList.add('subscribed');
        }, 1500);
    }
    
    function showNewsletterMessage(message, type) {
        if (!newsletterMessage) return;
        
        newsletterMessage.textContent = message;
        newsletterMessage.className = 'newsletter-message';
        newsletterMessage.classList.add(type);
        
        // Clear message after 5 seconds
        setTimeout(() => {
            newsletterMessage.textContent = '';
            newsletterMessage.className = 'newsletter-message';
        }, 5000);
    }
});