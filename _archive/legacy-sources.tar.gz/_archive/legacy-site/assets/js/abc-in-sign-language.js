const aslData = [
  { letter:'A', emoji:'✊', tip:'Thumb rests on the side of the fist, not tucked under.' },
  { letter:'B', emoji:'🖐️', tip:'Fingers flat together, thumb tucked across palm.' },
  { letter:'C', emoji:'🤏', tip:'Hand curves like the letter C, all fingers together.' },
  { letter:'D', emoji:'☝️', tip:'Index finger points up, other fingers touch thumb in a circle.' },
  { letter:'E', emoji:'🤙', tip:'All fingertips curl down to touch the thumb. Like a bent claw.' },
  { letter:'F', emoji:'👌', tip:'Index and thumb form a circle; other three fingers point up.' },
  { letter:'G', emoji:'👉', tip:'Index finger and thumb point sideways, like pointing a gun sideways.' },
  { letter:'H', emoji:'✌️', tip:'Index and middle fingers point sideways together, horizontally.' },
  { letter:'I', emoji:'🤙', tip:'Pinky extends up, all other fingers folded, thumb out.' },
  { letter:'J', emoji:'🤙', tip:'Like I but trace the letter J in the air with your pinky.' },
  { letter:'K', emoji:'🤞', tip:'Index up, middle finger angled out, thumb between them.' },
  { letter:'L', emoji:'👈', tip:'Index finger up, thumb out — classic L shape.' },
  { letter:'M', emoji:'✊', tip:'Three fingers fold over the thumb.' },
  { letter:'N', emoji:'✊', tip:'Two fingers fold over the thumb (one fewer than M).' },
  { letter:'O', emoji:'👌', tip:'All fingertips touch the thumb to form an O circle.' },
  { letter:'P', emoji:'👇', tip:'Like K but hand points downward.' },
  { letter:'Q', emoji:'🤏', tip:'Like G but hand points downward.' },
  { letter:'R', emoji:'🤞', tip:'Index and middle fingers crossed.' },
  { letter:'S', emoji:'✊', tip:'Fist with thumb wrapped over fingers — not tucked under like A.' },
  { letter:'T', emoji:'👊', tip:'Thumb is tucked between index and middle fingers.' },
  { letter:'U', emoji:'✌️', tip:'Index and middle fingers together, pointing up.' },
  { letter:'V', emoji:'✌️', tip:'Index and middle fingers spread in a V shape, pointing up.' },
  { letter:'W', emoji:'🤟', tip:'Three fingers — ring, middle, index — spread out in a W.' },
  { letter:'X', emoji:'☝️', tip:'Index finger hooks into a curved X shape.' },
  { letter:'Y', emoji:'🤙', tip:'Pinky and thumb extend out, other fingers folded.' },
  { letter:'Z', emoji:'☝️', tip:'Use index finger to draw a Z in the air.' },
];

const grid = document.getElementById('alphabetGrid');
let activeCard = null;

aslData.forEach((item, i) => {
  const card = document.createElement('div');
  card.className = 'letter-card';
  card.setAttribute('role','listitem');
  card.setAttribute('tabindex','0');
  card.setAttribute('aria-label', `Letter ${item.letter} in ASL`);
  card.innerHTML = `
    <span class="letter-big">${item.letter}</span>
    <span class="letter-hand" aria-hidden="true">${item.emoji}</span>
    <span class="letter-name">Sign ${item.letter}</span>
    <p class="letter-tip">${item.tip}</p>
  `;
  card.style.animationDelay = `${i * 0.025}s`;
  card.style.opacity = '0';
  card.style.animation = `fadeUp 0.4s ${i * 0.025}s forwards`;
  card.addEventListener('click', () => {
    if (activeCard && activeCard !== card) activeCard.classList.remove('active');
    card.classList.toggle('active');
    activeCard = card.classList.contains('active') ? card : null;
  });
  card.addEventListener('keypress', e => { if (e.key === 'Enter' || e.key === ' ') card.click(); });
  grid.appendChild(card);
});

// ── FAQ ACCORDION ──
document.querySelectorAll('.faq-q').forEach(btn => {
  btn.addEventListener('click', () => {
    const item = btn.closest('.faq-item');
    const open = item.classList.contains('open');
    document.querySelectorAll('.faq-item.open').forEach(el => {
      el.classList.remove('open');
      el.querySelector('.faq-q').setAttribute('aria-expanded','false');
    });
    if (!open) {
      item.classList.add('open');
      btn.setAttribute('aria-expanded','true');
    }
  });
});

// ── SCROLL REVEAL ──
const observer = new IntersectionObserver(entries => {
  entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); } });
}, { threshold: 0.12 });
document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

// ── QUIZ ──
let quizScore = 0, quizTotal = 0, quizAnswered = false;
const quizLetters = [...aslData];

function shuffle(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function loadQuestion() {
  quizAnswered = false;
  const shuffled = shuffle([...quizLetters]);
  const correct = shuffled[0];
  const options = shuffle([correct, shuffled[1], shuffled[2], shuffled[3]]);
  document.getElementById('quizEmoji').textContent = correct.emoji;
  document.getElementById('quizEmoji').setAttribute('aria-label', 'Identify this hand sign');
  document.getElementById('quizFeedback').textContent = '';
  document.getElementById('quizNext').style.display = 'none';

  const optContainer = document.getElementById('quizOptions');
  optContainer.innerHTML = '';
  options.forEach(opt => {
    const btn = document.createElement('button');
    btn.className = 'quiz-option';
    btn.textContent = opt.letter;
    btn.setAttribute('aria-label', `Letter ${opt.letter}`);
    btn.addEventListener('click', () => {
      if (quizAnswered) return;
      quizAnswered = true;
      quizTotal++;
      if (opt.letter === correct.letter) {
        quizScore++;
        btn.classList.add('correct');
        document.getElementById('quizFeedback').textContent = '✓ Correct! Great job!';
        document.getElementById('quizFeedback').style.color = 'var(--accent2)';
      } else {
        btn.classList.add('wrong');
        optContainer.querySelectorAll('.quiz-option').forEach(b => {
          if (b.textContent === correct.letter) b.classList.add('correct');
        });
        document.getElementById('quizFeedback').textContent = `✗ It was ${correct.letter}`;
        document.getElementById('quizFeedback').style.color = 'var(--accent)';
      }
      document.getElementById('quizScore').textContent = `Score: ${quizScore} / ${quizTotal}`;
      document.getElementById('quizNext').style.display = 'inline-block';
    });
    optContainer.appendChild(btn);
  });
}

document.getElementById('quizNext').addEventListener('click', loadQuestion);
loadQuestion();